document.write("Ejemplo de uso de For (JavaScript)");
// FOR es una estructura de control es de tipo Repetitiva (Bucles), 
// Hasta que se cumpla la condicion
// While 
// Mientras se cumpla la condicion 
//Cuenta con tres parametros
// 1- La inicializacion de la variable
// 2- Condicion a ocupar 
// 3- Incremento